<!DOCTYPE>

<head>

	<title>Meyerson Chiropractic-About Dr. Jason</title>
	<meta charset="utf-8" >
	<meta name="Chiropractic Office" content="Meyerson Chiropractic">
	<meta name="Dr Jason Meyerson" content="SitePoint">

		<link rel="stylesheet" href="style.css"  type="text/css" media="screen" />
		<link rel="stylesheet" href="about.css"  type="text/css" media="screen" />
		<!--[if  lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	
		<![endif]-->
</head>

<body>
	<?php include_once('header.php');?>
    

      
        <div id="about">

                    <img class="img_kids_about" src="meyerson_chiroprac_kids_about.jpg" alt="Dr Jasons children" >
                 
                            <p><img  class="img_family_about" src="meyerson_chiroprac_family_about.jpg"<Hello, my name is Dr. Jason Meyerson and I have been practicing Chiropractic in the Baltimore area since 1996. I graduated with honors in 1995 from Life Chiropractic College West, in Northern California. <br /><br />I truly love being a chiropractor and working with the incredible human body, while helping people reach their health goals through chiropractic. I am married to Kim. <br /><br />We have 1 son, Jacob, 1 daughter, Kaitlyn, and 1 dog, Hunter.   I adjust everyone from infants to the elderly, football players to ballerinas, marathon runners to desk jockeys, pregnant moms and whole families, as well as special needs individuals <br /><br />I use a combination of styles and techniques to best serve each person.</p>     
              
      </div>  
              			
        <div id="panel">

                          <img src="A4F64D7C2-4E20-4784-874C-77375F8F0E24.jpg">
                 
                         <img src="About_Dr._Jason_files/0514266D-295A-41F5-A3BC-CC3E413080C8.jpg">
                  
                          <img src="About_Dr._Jason_files/D828F993-1442-4C1F-8037-B0721D1E9D47.jpg">             
                   
        </div>
<?php include('footer.html');?>

</body>
</html>    