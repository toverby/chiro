	<div id="navigation">

		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="firstvisit.php">First Visit Tour</a></li>
			<li><a href="about.php">About MC</a></li>
			<li><a href="links.php">Knowledge</a></li>
			<li><a href="contact.php">Make App.</a></li>
			<li><a href="media.php">Videos</a></li>

		</ul>
	</div>